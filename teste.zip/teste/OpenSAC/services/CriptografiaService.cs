﻿using System.Security.Cryptography;
using System.Text;

namespace OpenSAC.services
{
    public class CriptografiaService
    {
        private static readonly byte[] chave;
        private static readonly byte[] vetorInicializacao;
        private byte[]? dadosCriptografados;

        static CriptografiaService()
        {
            using var aes = Aes.Create();
            chave = aes.Key;
            vetorInicializacao = aes.IV;
        }

        public void CriptografarCredenciais(string usuario, string senha)
        {
            var credenciaisTexto = $"{usuario}:{senha}";
            using var aes = Aes.Create();
            aes.Key = chave;
            aes.IV = vetorInicializacao;

            var cifrador = aes.CreateEncryptor();
            var bytesCredenciais = Encoding.UTF8.GetBytes(credenciaisTexto);
            dadosCriptografados = cifrador.TransformFinalBlock(bytesCredenciais, 0, bytesCredenciais.Length);
        }

        public List<string> DescriptografarCredenciais()
        {
            if (dadosCriptografados == null)
                throw new InvalidOperationException("Não há credenciais armazenadas.");

            using var aes = Aes.Create();
            aes.Key = chave;
            aes.IV = vetorInicializacao;

            var decifrador = aes.CreateDecryptor();
            var bytesDecifrados = decifrador.TransformFinalBlock(dadosCriptografados, 0, dadosCriptografados.Length);
            var textoCredenciais = Encoding.UTF8.GetString(bytesDecifrados);
            var partes = textoCredenciais.Split(':');

            return new List<string>(partes);
        }
    }
}