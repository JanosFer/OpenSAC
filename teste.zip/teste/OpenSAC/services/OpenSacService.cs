﻿using FlaUI.Core.AutomationElements;
using FlaUI.UIA3;
using OpenSAC.model;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;

namespace OpenSAC.services
{
    public class OpenSacService
    {
        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern bool LogonUser(
            string lpszUsername,
            string lpszDomain,
            string lpszPassword,
            int dwLogonType,
            int dwLogonProvider,
            out IntPtr phToken);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr handle);

        private const int LOGON32_LOGON_NETWORK = 3;
        private const int LOGON32_PROVIDER_DEFAULT = 0;

        public bool Monitorando { get; set; }

        public ObservableCollection<Programa> SacsAbertos { get; set; }
        public ObservableCollection<Programa> SacsFechados { get; set; }
        public ObservableCollection<Programa> SacsProcessando { get; set; }
        public ObservableCollection<Programa> SacsErros { get; set; }

        public List<string> ScriptsErros { get; set; }
        public string ScriptConcluido { get; set; }

        private readonly CriptografiaService _criptografiaService;

        public OpenSacService()
        {
            Monitorando = false;

            SacsAbertos = new ObservableCollection<Programa>();
            SacsFechados = new ObservableCollection<Programa>();
            SacsProcessando = new ObservableCollection<Programa>();
            SacsErros = new ObservableCollection<Programa>();

            ScriptsErros = new List<string>();
            ScriptConcluido = string.Empty;

            _criptografiaService = new CriptografiaService();
        }

        //LOGIN

        public bool ValidarLogin(string usuario, string senha)
        {
            IntPtr tokenHandle = IntPtr.Zero;
            try
            {
                string dominio = Environment.MachineName;

                bool resultado = LogonUser(
                    usuario,
                    dominio,
                    senha,
                    LOGON32_LOGON_NETWORK,
                    LOGON32_PROVIDER_DEFAULT,
                    out tokenHandle);

                if (resultado)
                {
                    _criptografiaService.CriptografarCredenciais(usuario, senha);
                    return true;
                }
                else
                {
                    int erro = Marshal.GetLastWin32Error();
                    MessageBox.Show($"Falha no login. Código do erro: {erro}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao validar login: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            finally
            {
                if (tokenHandle != IntPtr.Zero)
                {
                    CloseHandle(tokenHandle);
                }
            }
        }

        public void LogarSAC(int pid)
        {
            try
            {
                List<String> credenciais = _criptografiaService.DescriptografarCredenciais();

                using (var app = FlaUI.Core.Application.Attach(pid))
                {
                    using (var automation = new UIA3Automation())
                    {
                        var janela = app.GetMainWindow(automation);
                        if (janela == null)
                        {
                            throw new InvalidOperationException("Janela principal não encontrada.");
                        }

                        janela.WaitUntilClickable(TimeSpan.FromSeconds(5));

                        var campoUsuario = janela.FindFirstDescendant(cf => cf.ByAutomationId("txtUsuario"))?.AsTextBox();
                        var campoSenha = janela.FindFirstDescendant(cf => cf.ByAutomationId("txtSenha"))?.AsTextBox();
                        var botaoOk = janela.FindFirstDescendant(cf => cf.ByAutomationId("btnOK"))?.AsButton();

                        if (campoUsuario != null && campoSenha != null && botaoOk != null)
                        {
                            campoUsuario.Text = credenciais[0];
                            campoSenha.Text = credenciais[1];
                            botaoOk.Invoke();
                        }
                        else
                        {
                            MessageBox.Show("Não foi possível localizar campos de login na janela.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao preencher o login: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //ESCOLHA INSTÂNCIAS

        public void CarregarProgramas(string baseSelecionada)
        {
            SacsFechados.Clear();

            if (baseSelecionada.Equals("PRIVATE", StringComparison.OrdinalIgnoreCase))
            {
                foreach (var programaEnum in Enum.GetValues(typeof(PRIVATE)))
                {
                    SacsFechados.Add(new Programa((string)programaEnum));
                }
            }
            else if (baseSelecionada.Equals("PRIME", StringComparison.OrdinalIgnoreCase))
            {
                foreach (var programaEnum in Enum.GetValues(typeof(PRIME)))
                {
                    SacsFechados.Add(new Programa((string)programaEnum));
                }
            }
        }

        //CONTROLE INSTÂNCIAS

        private bool AbrirProcesso(Programa programa)
        {
            if (!File.Exists(programa.Caminho))
            {
                MessageBox.Show($"O caminho não existe: {programa.Caminho}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return true;
            }

            try
            {
                var processo = Process.Start(new ProcessStartInfo
                {
                    FileName = programa.Caminho,
                    UseShellExecute = true
                });

                if (processo == null)
                {
                    MessageBox.Show($"Não foi possível iniciar o SAC: {programa.Caminho}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                    return true;
                }

                programa.Pid = processo.Id;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao abrir o SAC no caminho {programa.Caminho}: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                programa.Status = "Aberto";
                SacsAbertos.Add(programa);
                SacsFechados.Remove(programa);
            }
            return false;
        }

        public void AbrirInstancias(List<string> nomesProgramas)
        {
            foreach (Programa programa in SacsFechados)
            {
                foreach (string programaParaAbrir in nomesProgramas)
                {
                    if (programaParaAbrir.Equals(programa.Nome))
                    {
                        bool continuar = AbrirProcesso(programa);

                        if (continuar)
                        {
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                }
            }
        }

        public void AbrirTodos()
        {
            foreach (Programa programa in SacsFechados)
            {
                bool continuar = AbrirProcesso(programa);

                if (continuar)
                {
                    continue;
                }
                else
                {
                    break;
                }
            }
        }

        private bool FecharProcesso(Programa programa)
        {
            if (programa.Pid.HasValue)
            {
                try
                {
                    var processo = Process.GetProcessById(programa.Pid.Value);
                    processo.Kill();
                    processo.WaitForExit();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro ao fechar o SAC {programa.Nome}: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    programa.Status = "Fechado";
                    SacsFechados.Add(programa);
                    SacsAbertos.Remove(programa);
                }
            }
            return false;
        }

        public void FecharInstancias(List<string> nomesProgramas)
        {
            foreach (Programa programa in SacsAbertos)
            {
                foreach (string programasParaFechar in nomesProgramas)
                {
                    if (programasParaFechar.Equals(programa.Nome) && programa.Pid.HasValue)
                    {
                        bool continuar = FecharProcesso(programa);

                        if (!continuar)
                        {
                            break;
                        }
                    }
                }
            }
        }

        public void FecharTodos()
        {
            foreach (Programa programa in SacsAbertos)
            {
                FecharProcesso(programa);
            }
        }

        public void IniciarMonitoramento()
        {

            Monitorando = true;
            _ = Task.Run(MonitorarProcessos);
        }

        public void PararMonitoramento()
        {
            Monitorando = false;
        }

        private async Task MonitorarProcessos()
        {
            while (Monitorando)
            {
                await Task.Delay(5000);
                var finalizados = SacsAbertos.Where(p =>
                {
                    try
                    {
                        Process.GetProcessById((int)p.Pid);
                        return false;
                    }
                    catch
                    {
                        return true;
                    }
                }).ToList();
                foreach (var programa in finalizados)
                {
                    App.Current.Dispatcher.Invoke(() =>
                    {
                        programa.Status = "Fechado";
                        SacsFechados.Add(programa);
                        SacsAbertos.Remove(programa);
                    });
                }
            }
        }
    }
}