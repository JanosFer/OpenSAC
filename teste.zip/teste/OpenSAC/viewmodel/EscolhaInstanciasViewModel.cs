﻿using OpenSAC.helpers;
using OpenSAC.model;
using OpenSAC.services;
using OpenSAC.view;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;

namespace OpenSAC.viewmodel
{
    public class EscolhaInstanciasViewModel(OpenSacService controller) : INotifyPropertyChanged
    {
        public ObservableCollection<ServidorOpcao> Servidores { get; set; } = new();
        private string _baseSelecionada;
        public string BaseSelecionada
        {
            get => _baseSelecionada;
            set
            {
                if (_baseSelecionada != value)
                {
                    _baseSelecionada = value;
                    OnPropertyChanged();
                }
            }
        }
        public bool MarcarTodos
        {
            get => _marcarTodos;
            set
            {
                if (_marcarTodos != value)
                {
                    _marcarTodos = value;
                    OnPropertyChanged();
                    AtualizarEstadoCheckboxes();
                    AtualizarMaxInstancias();
                }
            }
        }

        public int QuantidadeInstancias
        {
            get => _quantidadeInstancias;
            set
            {
                if (_quantidadeInstancias != value)
                {
                    _quantidadeInstancias = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(TextoQuantidadeMaxima));
                }
            }
        }

        public string TextoQuantidadeMaxima => $"Quantidade máxima: {MaxInstancias}";

        private int MaxInstancias;
        private bool _marcarTodos;
        private int _quantidadeInstancias;

        public event PropertyChangedEventHandler? PropertyChanged = null;

        public ICommand AtualizarBaseCommand => new RelayCommand(_ => AtualizarCheckboxes());
        public ICommand ConfirmarCommand => new RelayCommand(_ => Confirmar());

        public void AtualizarCheckboxes()
        {
            Servidores.Clear();
            controller.SacsFechados.Clear();

            if (BaseSelecionada == "PRIVATE" || BaseSelecionada == "PRIME")
            {
                AdicionarServidores();
            }
            MarcarTodos = false;
            AtualizarEstadoCheckboxes();
            AtualizarMaxInstancias();
        }

        public void AdicionarServidores()
        {
            controller.CarregarProgramas(BaseSelecionada);

            foreach (var programa in controller.SacsFechados)
            {
                var nome = programa.Nome;

                if (!nome.Contains('_'))
                {
                    var servidor = new ServidorOpcao { Nome = nome, Selecionado = false };
                    servidor.PropertyChanged += (_, __) => AtualizarMaxInstancias();
                    Servidores.Add(servidor);
                }
            }
        }

        public void AtualizarEstadoCheckboxes()
        {
            foreach (var servidor in Servidores)
            {
                servidor.Selecionado = MarcarTodos;
                servidor.Habilitado = !MarcarTodos;
            }
        }

        public void AtualizarMaxInstancias()
        {
            int selecionados = Servidores.Count(s => s.Selecionado);
            MaxInstancias = (BaseSelecionada == "PRIVATE" ? 4 : BaseSelecionada == "PRIME" ? 8 : 0) * selecionados;
            QuantidadeInstancias = MaxInstancias;
            OnPropertyChanged(nameof(TextoQuantidadeMaxima));
        }

        public void AbrirJanelaControleInstancias()
        {
            var janela = new ControleInstanciasWindow(controller);
            janela.Show();

            var janelaAtual = Application.Current.Windows
                .OfType<Window>()
                .FirstOrDefault(w => w.DataContext == this);

            janelaAtual?.Close();
        }
        private void Confirmar()
        {
            int instanciasSolicitadas = QuantidadeInstancias;

            if (string.IsNullOrEmpty(BaseSelecionada))
            {
                MessageBox.Show("Por favor selecione uma base.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (instanciasSolicitadas > MaxInstancias)
            {
                MessageBox.Show("A quantidade de instâncias solicitadas é maior que a máxima permitida.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (instanciasSolicitadas <= 0)
            {
                MessageBox.Show("A quantidade de instâncias solicitadas é inválida.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            foreach (var servidor in Servidores)
            {
                if (!servidor.Selecionado)
                    continue;

                List<string> nomesProgramas = new List<string>();

                foreach (Programa programa in controller.SacsFechados)
                {
                    if (!programa.Nome.Contains(servidor.Nome))
                    { 
                        continue;
                    }
                    nomesProgramas.Add(programa.Nome);
                   controller.AbrirInstancias(nomesProgramas);
                }
            }

            controller.IniciarMonitoramento();
            AbrirJanelaControleInstancias();
        }

        protected void OnPropertyChanged([CallerMemberName] string nomePropriedade = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nomePropriedade));
        }
    }
}
