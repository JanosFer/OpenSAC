﻿using OpenSAC.helpers;
using System.ComponentModel;
using OpenSAC.services;
using OpenSAC.view;
using System.Windows;
using System.Windows.Input;

namespace OpenSAC.viewmodel
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private string usuario = string.Empty;
        private string senha = string.Empty;
        private readonly OpenSacService controller;

        public string Usuario
        {
            get => usuario;
            set
            {
                usuario = value;
                OnPropertyChanged(nameof(Usuario));
            }
        }

        public string Senha
        {
            get => senha;
            set
            {
                senha = value;
                OnPropertyChanged(nameof(Senha));
            }
        }

        public ICommand ConfirmarLoginCommand { get; }

        public LoginViewModel()
        {
            controller = new OpenSacService();
            ConfirmarLoginCommand = new RelayCommand(_ => ConfirmarLogin());
        }

        private void ConfirmarLogin()
        {
            if (string.IsNullOrWhiteSpace(Usuario) || string.IsNullOrWhiteSpace(Senha))
            {
                MessageBox.Show("Usuário e Senha devem ser preenchidos!", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                if (controller.ValidarLogin(Usuario, Senha))
                {
                    var escolhaInstancias = new EscolhaInstanciasWindow(controller);
                    escolhaInstancias.Show();

                    var janelaAtual = Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w.DataContext == this);

                    janelaAtual?.Close();
                }
                else
                {
                    MessageBox.Show("Login inválido!", "Erro", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro Interno", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string nome) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nome));
    }
}
