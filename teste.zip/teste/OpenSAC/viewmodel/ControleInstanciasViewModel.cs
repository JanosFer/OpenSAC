﻿using OpenSAC.helpers;
using OpenSAC.model;
using OpenSAC.services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;

namespace OpenSAC.viewmodel
{
    public class ControleInstanciasViewModel : INotifyPropertyChanged
    {
        private OpenSacService controller;
        private bool mostrarInputScripts = false;
        private bool _netReportSelecionado;
        private bool _processamentoGeralSelecionado;
        private string _scriptsTexto = "";
        private List<string> _checkboxesMarcadas;

        public ICommand AbrirTodosCommand { get; }
        public ICommand FecharTodosCommand { get; }
        public ICommand AbrirCommand { get; }
        public ICommand FecharCommand { get; }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string nomePropriedade = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nomePropriedade));
        }

        public ControleInstanciasViewModel(OpenSacService controller)
        {
            this.controller = controller;
            AbrirTodosCommand = new RelayCommand(_ => AbrirTodos(), _ => controller.SacsFechados.Any());
            FecharTodosCommand = new RelayCommand(_ => FecharTodos(), _ => controller.SacsAbertos.Any());
            AbrirCommand = new RelayCommand(param => AbrirPrograma(param as Programa), param => (param as Programa)?.PodeAbrir == true);
            FecharCommand = new RelayCommand(param => FecharPrograma(param as Programa), param => (param as Programa)?.PodeFechar == true);
            _checkboxesMarcadas = new List<string>();

            this.controller.IniciarMonitoramento();
        }
        public bool MostrarInputScripts
        {
            get => mostrarInputScripts;
            set
            {
                if (mostrarInputScripts != value)
                {
                    mostrarInputScripts = value;
                    OnPropertyChanged(nameof(MostrarInputScripts));
                }
            }
        }
        public string ScriptsTexto
        {
            get => _scriptsTexto;
            set
            {
                if (_scriptsTexto != value)
                {
                    _scriptsTexto = value;
                    OnPropertyChanged(nameof(ScriptsTexto));
                }
            }
        }

        private ObservableCollection<Modulo> _modulos = new ObservableCollection<Modulo>();
        public ObservableCollection<Modulo> Modulos
        {
            get => _modulos;
            set
            {
                _modulos = value;
                OnPropertyChanged(nameof(Modulos));
            }
        }
        public bool PodeAbrirTodos => controller.SacsFechados.Any(p => p.Status == "Aberto");
        public bool PodeFecharTodos => controller.SacsAbertos.Any(p => p.Status == "Fechado");

        private void CarregarCheckboxes()
        {
            Modulos.Clear();

            if (ProcessamentoGeralSelecionado)
            {
                List<string> modulosDisponiveis = new List<string>
                {
                    "Renda Variável",
                    "Futuros",
                    "Renda Fixa",
                    "Swap",
                    "Outros",
                    "Clientes"
                };
            }

            OnPropertyChanged(nameof(Modulos));
        }
        public bool NetReportSelecionado
        {
            get => _netReportSelecionado;
            set
            {
                if (_netReportSelecionado != value)
                {
                    _netReportSelecionado = value;
                    OnPropertyChanged(nameof(NetReportSelecionado));
                    if (value) CarregarCheckboxes();
                }
            }
        }

        public bool ProcessamentoGeralSelecionado
        {
            get => _processamentoGeralSelecionado;
            set
            {
                if (_processamentoGeralSelecionado != value)
                {
                    _processamentoGeralSelecionado = value;
                    OnPropertyChanged(nameof(ProcessamentoGeralSelecionado));
                    if (value) CarregarCheckboxes();
                }
            }
        }

        private void AtualizarBotoes()
        {
            OnPropertyChanged(nameof(PodeAbrirTodos));
            OnPropertyChanged(nameof(PodeFecharTodos));
        }

        public void AbrirPrograma(Programa programa)
        {
            try
            {
                List<string> nomeProgramas = new List<string> { programa.Nome };
                controller.AbrirInstancias(nomeProgramas);

                programa.Status = "Aberto";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao abrir o programa: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void FecharPrograma(Programa programa)
        {
            try
            {
                if (programa.Pid.HasValue)
                {
                    List<string> nomeProgramas = new List<string> { programa.Nome };
                    controller.FecharInstancias(nomeProgramas);
                    programa.Pid = null;
                }

                programa.Status = "Fechado";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao fechar o programa: {ex.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void AbrirTodos()
        {
            try
            {
                foreach (var programa in controller.SacsFechados)
                {
                    AbrirPrograma(programa);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show($"Erro ao abrir todos os programas: {e.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void FecharTodos()
        {
            try
            {
                controller.FecharTodos();
            }
            catch (Exception e)
            {
                MessageBox.Show($"Erro ao fechar todos os programas: {e.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public List<string> checkboxes_marcadas
        {
            get => _checkboxesMarcadas;
            set { _checkboxesMarcadas = value; OnPropertyChanged(); }
        }

        //public void Confirmar()
        //{
        //    var listaScripts = string.IsNullOrWhiteSpace(ScriptsTexto)
        //        ? new List<string>()
        //        : ScriptsTexto.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries).ToList();

        //    bool automatizado = RodarScripts;
        //    string data = DataProcessamento;

        //    if (NetReportSelecionado && controller.SACs_abertos.Any())
        //    {
        //        try
        //        {
        //            controller.RodaAutomacao(data, "NetReport", automatizado, null, listaScripts);
        //        }
        //        catch (Exception e)
        //        {
        //            MessageBox.Show($"Erro na automação: {e.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
        //        }
        //    }
        //    else if (ProcessamentoGeralSelecionado && controller.SACs_abertos.Any())
        //    {
        //        if (checkboxes_marcadas.Any())
        //        {
        //            try
        //            {
        //                controller.RodaAutomacao(data, "Processamento Geral", automatizado, checkboxes_marcadas, listaScripts);
        //            }
        //            catch (Exception e)
        //            {
        //                MessageBox.Show($"Erro na automação: {e.Message}", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
        //            }
        //        }
        //        else
        //        {
        //            MessageBox.Show("É necessário marcar ao menos um Módulo para iniciar o processamento", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
        //        }
        //    }
        //    else if (!controller.SacsAbertos.Any())
        //    {
        //        MessageBox.Show("Nenhuma instância de SAC aberta, por favor, abra alguma antes de rodar a automação.", "Aviso", MessageBoxButton.OK, MessageBoxImage.Warning);
        //    }
        //}
    }
}
