﻿using System.Windows;
using System.Windows.Controls;

namespace OpenSAC.helpers
{
    public static class SenhaHelper
    {
        public static readonly DependencyProperty SenhaVinculadaProperty =
            DependencyProperty.RegisterAttached(
                "SenhaVinculada",
                typeof(string),
                typeof(SenhaHelper),
                new FrameworkPropertyMetadata(
                    string.Empty,
                    FrameworkPropertyMetadataOptions.BindsTwoWayByDefault,
                    AoAlterarSenhaVinculada
                )
            );

        public static string GetSenhaVinculada(DependencyObject obj) => (string)obj.GetValue(SenhaVinculadaProperty);
        public static void SetSenhaVinculada(DependencyObject obj, string valor) => obj.SetValue(SenhaVinculadaProperty, valor);

        private static void AoAlterarSenhaVinculada(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var caixa = d as PasswordBox;
            if (caixa == null) return;

            if (caixa.Password != (string)e.NewValue)
                caixa.Password = (string)e.NewValue;

            caixa.PasswordChanged -= AoSenhaAlterada;
            caixa.PasswordChanged += AoSenhaAlterada;
        }

        private static void AoSenhaAlterada(object sender, RoutedEventArgs e)
        {
            if (sender is PasswordBox caixa)
                SetSenhaVinculada(caixa, caixa.Password);
        }

        public static readonly DependencyProperty AtivarVinculoProperty =
            DependencyProperty.RegisterAttached(
                "AtivarVinculo",
                typeof(bool),
                typeof(SenhaHelper),
                new PropertyMetadata(false, AoAlterarAtivarVinculo)
            );

        public static bool GetAtivarVinculo(DependencyObject dp) => (bool)dp.GetValue(AtivarVinculoProperty);
        public static void SetAtivarVinculo(DependencyObject dp, bool valor) => dp.SetValue(AtivarVinculoProperty, valor);

        private static void AoAlterarAtivarVinculo(DependencyObject dp, DependencyPropertyChangedEventArgs e)
        {
            if (dp is PasswordBox caixa)
            {
                if ((bool)e.OldValue)
                    caixa.PasswordChanged -= AoSenhaAlterada;
                if ((bool)e.NewValue)
                    caixa.PasswordChanged += AoSenhaAlterada;
            }
        }
    }
}
