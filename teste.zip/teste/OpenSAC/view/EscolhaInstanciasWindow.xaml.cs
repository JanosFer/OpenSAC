﻿using OpenSAC.services;
using OpenSAC.viewmodel;
using System.Windows;

namespace OpenSAC.view
{
    public partial class EscolhaInstanciasWindow : Window
    {
        public EscolhaInstanciasWindow(OpenSacService controller)
        {
            InitializeComponent();
            DataContext = new EscolhaInstanciasViewModel(controller);
        }
    }
}
