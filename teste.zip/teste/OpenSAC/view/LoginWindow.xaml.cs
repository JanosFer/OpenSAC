﻿using OpenSAC.viewmodel;
using System.Windows;

namespace OpenSAC.view
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            DataContext = new LoginViewModel();
        }
    }
}
