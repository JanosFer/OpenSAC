﻿using OpenSAC.services;
using OpenSAC.viewmodel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OpenSAC.view
{

    public partial class ControleInstanciasWindow : Window
    {
        public ControleInstanciasWindow(OpenSacService controller)
        {
            InitializeComponent();
            this.DataContext = new ControleInstanciasViewModel(controller);
        }
    }
}
