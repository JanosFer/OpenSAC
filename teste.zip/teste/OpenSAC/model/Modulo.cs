﻿namespace OpenSAC.model
{
    public class Modulo
    {
        public string? Nome { get; set; }
    }
}
