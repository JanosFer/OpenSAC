﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace OpenSAC.model
{
    public class Programa : INotifyPropertyChanged
    {
        private string _status = "Fechado";
        private int? _pid;

        public string Nome { get; set; }
        public string Caminho { get; set; }

        public string Status
        {
            get => _status;
            set
            {
                if (_status != value)
                {
                    _status = value;
                    OnPropertyChanged();
                    OnPropertyChanged(nameof(CorStatus));
                    OnPropertyChanged(nameof(PodeAbrir));
                    OnPropertyChanged(nameof(PodeFechar));
                }
            }
        }

        public int? Pid
        {
            get => _pid;
            set
            {
                if (_pid != value)
                {
                    _pid = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool PodeAbrir => Status != "Aberto";
        public bool PodeFechar => Status == "Aberto";

        public string CorStatus => Status switch
        {
            "Aberto" => "#008000",
            "Fechado" => "#FF0000",
            "Processando" => "#569CD6",
            "Erro" => "#FFA500",
            _ => "#333333"
        };

        public Programa(string nome)
        {
            Nome = nome;
            Caminho = GerarCaminho(nome);
            Status = "Fechado";
            Pid = null;
            PropertyChanged = delegate { };
        }

        private string GerarCaminho(string nome)
        {
            string caminhoBase = "/Atalhos_Produção/TOTVS/";
            string servidorInstancia;

            if (char.IsDigit(nome[^1]))
            {
                string instancia = nome[^2..];
                string servidor = nome[..^2];
                servidorInstancia = $"{servidor}/SAC{instancia}.lnk";
            }
            else
            {
                servidorInstancia = $"{nome}/SAC.lnk";
            }

            return $"{caminhoBase}{servidorInstancia}";
        }

        public event PropertyChangedEventHandler? PropertyChanged; 

        protected void OnPropertyChanged([CallerMemberName] string? nome = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nome));
        }
    }
}