﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace OpenSAC.model
{
    public class ServidorOpcao : INotifyPropertyChanged
    {
        public string Nome { get; set; }

        private bool _selecionado;
        public bool Selecionado
        {
            get => _selecionado;
            set { _selecionado = value; OnPropertyChanged(); }
        }

        private bool _habilitado = true;
        public bool Habilitado
        {
            get => _habilitado;
            set { _habilitado = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string prop = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
    }
}
